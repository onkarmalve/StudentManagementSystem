package model;

public class Student {
	public int id;
	public String  name;
	public double marks;
	
	public Student()
	{
		id=0;
		name=null;
		marks=0;
	}
	public Student(int id,String name,double marks)
	{
		this.id=id;
		this.name=name;
		this.marks=marks;
	}
	
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public double getMarks()
	{
		return marks;
	}
	public void setMarks(double marks)
	{
		this.marks=marks;
	}
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id=id;
	}
	
	public String toString()
	{
		return "Id ="+id+"\n Name = "+name+"\n Marks =" +marks;	
	}

}
