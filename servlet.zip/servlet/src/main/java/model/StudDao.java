package model;

import java.sql.*;

import java.sql.Connection;
import java.sql.SQLException;

public class StudDao implements dbservice {

	
	String url="jdbc:mysql://localhost:3306/onks";
	String uname="root";
	String pass="root";
	Connection con;
	PreparedStatement ps;
	
	public Connection getconnection() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(url,uname,pass);
		return con;
	}
	
	public StudDao() throws ClassNotFoundException, SQLException
	{
		con=getconnection();
	}
	
	
	public boolean addstud(Student studobj) throws SQLException
	{
		ps=con.prepareStatement("insert into student values (?,?,?)");
		ps.setInt(1, studobj.getId());
		ps.setString(2, studobj.getName());
		ps.setDouble(3, studobj.getMarks());
		
		int ans=ps.executeUpdate();
		
		if(ans>0)
		return true;
		else
		return false;
		
	}
	
	public boolean deletestud(Student std) throws SQLException
	{
		ps=con.prepareStatement("delete from student where id =?");
		ps.setInt(1, std.getId());
		
		int ans=ps.executeUpdate();
		
		if(ans>0)
		return true;
		else 
		return false;
		
	}
	
	public boolean updatestud(Student std) throws SQLException
	{
		ps=con.prepareStatement("update student set name=?,marks=? where id =?");
		ps.setString(1, std.getName());
		ps.setDouble(2, std.getMarks());
		ps.setInt(3, std.getId());
		
		int ans=ps.executeUpdate();
		
		if(ans>0)
		return true;
		else 
		return false;
		
	}
	
	public Student show(Student std) throws SQLException
	{
		
		ps=con.prepareStatement("select * from student where id =?");
		ps.setInt(1, std.getId());
		
		ResultSet rs=ps.executeQuery();
		
		if(rs.next())
		{
			std.setId(rs.getInt(1));
			std.setName(rs.getString(2));
			std.setMarks(rs.getDouble(3));
		
		
		}
		return std;
			
		
		
	}
	
	

}
