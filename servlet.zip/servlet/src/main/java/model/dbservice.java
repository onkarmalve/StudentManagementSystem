package model;

import java.sql.Connection;
import java.sql.SQLException;

public interface dbservice {

	
	public Connection getconnection() throws ClassNotFoundException,SQLException;
	
}
