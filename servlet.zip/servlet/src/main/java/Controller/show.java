package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.StudDao;
import model.Student;

/**
 * Servlet implementation class show
 */
public class show extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public show() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw = response.getWriter();
		
		int id=Integer.parseInt(request.getParameter("id"));
		Student std=new Student();
		std.setId(id);
		
	
		try {
			StudDao dao= new StudDao();
			Student student=dao.show(std);
			pw.write("\n <h1><center> Student Are</center></h1>\n");
			pw.write("<center><div style=\"box-shadow:black 1px 1px 2px 2px; width:300px;\">");
			pw.write("<h1>\n Id = "+student.getId()+"</h1>");
			pw.write("<h1>\n Name = "+student.getName()+"</h1>");
			pw.write("<h1>\n Marks = "+student.getMarks()+"</h1>");
			pw.write("</div></center>");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
					
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
